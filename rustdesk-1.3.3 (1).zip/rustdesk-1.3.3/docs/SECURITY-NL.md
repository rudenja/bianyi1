# Veiligheidsbeleid

## Een Kwetsbaarheid Melden

Wij hechten veel waarde aan de veiligheid van het project. We moedigen alle gebruikers aan om kwetsbaarheden die ze ontdekken 
aan ons te melden. Als u een beveiligingslek in het RustDesk project vindt, meld dit dan op verantwoorde wijze door 
een e-mail te sturen naar info@rustdesk.com.

Op dit moment hebben we geen bug premie programma. We zijn een klein team dat een groot probleem probeert op te lossen. 
We verzoeken u dringend om alle kwetsbaarheden op verantwoorde wijze te melden, zodat we verder kunnen bouwen aan 
een veilige applicatie voor de hele gemeenschap.
